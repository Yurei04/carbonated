let activeTabId = null;
let startTime = null;
let currentUrl = null;

// Track active tab changes
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  saveCurrentSession();
  activeTabId = activeInfo.tabId;
  const tab = await chrome.tabs.get(activeTabId);
  startTracking(tab.url);
});

// Track URL changes in current tab
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabId === activeTabId && changeInfo.url) {
    saveCurrentSession();
    startTracking(changeInfo.url);
  }
});

// Track when window focus changes
chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    saveCurrentSession();
    activeTabId = null;
  }
});

function startTracking(url) {
  currentUrl = url;
  startTime = Date.now();
}

function saveCurrentSession() {
  if (!currentUrl || !startTime) return;
  
  const duration = (Date.now() - startTime) / 1000; // seconds
  const carbonPerSecond = 0.02; // grams CO2 per second (adjustable)
  const carbonEmitted = duration * carbonPerSecond;
  
  chrome.storage.local.get(['totalCarbon', 'sessions'], (result) => {
    const newTotal = (result.totalCarbon || 0) + carbonEmitted;
    const sessions = result.sessions || [];
    
    sessions.push({
      url: currentUrl,
      duration: duration,
      carbon: carbonEmitted,
      timestamp: Date.now()
    });
    
    // Keep only last 100 sessions
    if (sessions.length > 100) sessions.shift();
    
    chrome.storage.local.set({ 
      totalCarbon: newTotal,
      sessions: sessions 
    });
  });
  
  currentUrl = null;
  startTime = null;
}