const carbonPerSecond = 0.02; // grams CO2 per second
let intervalId = null;
let sessionStart = Date.now();
let currentSessionCarbon = 0;

// Update display every second
function startLiveCounter() {
  intervalId = setInterval(() => {
    currentSessionCarbon += carbonPerSecond;
    document.getElementById('currentCarbon').textContent = 
      currentSessionCarbon.toFixed(2);
  }, 1000);
}

// Load and display stats
async function updateStats() {
  const result = await chrome.storage.local.get(['totalCarbon', 'sessions']);
  
  const totalCarbon = result.totalCarbon || 0;
  document.getElementById('totalCarbon').textContent = totalCarbon.toFixed(1);
  
  // Calculate total time
  const sessions = result.sessions || [];
  const totalTime = sessions.reduce((sum, s) => sum + s.duration, 0);
  document.getElementById('timeSpent').textContent = 
    Math.round(totalTime / 60);
  
  // Get current tab URL
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs[0]) {
    const url = new URL(tabs[0].url);
    document.getElementById('currentSite').textContent = url.hostname;
  }
}

// Reset button
document.getElementById('reset').addEventListener('click', () => {
  chrome.storage.local.set({ totalCarbon: 0, sessions: [] });
  currentSessionCarbon = 0;
  updateStats();
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  startLiveCounter();
  updateStats();
  
  // Update stats every 5 seconds
  setInterval(updateStats, 5000);
});

// Cleanup on close
window.addEventListener('unload', () => {
  if (intervalId) clearInterval(intervalId);
});